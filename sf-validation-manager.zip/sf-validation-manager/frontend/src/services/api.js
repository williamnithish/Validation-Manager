/**
 * api.js
 * Centralized Axios instance for all backend API calls.
 */

import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api`
  : '/api';

const api = axios.create({
  baseURL: BASE_URL,
  withCredentials: true, // Send session cookies with every request
  headers: { 'Content-Type': 'application/json' },
  timeout: 60000, // 60s timeout (deploy polling can be slow)
});

// ─── Response interceptor: unwrap errors ────────────────────────────────────
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const message =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      'An unknown error occurred.';
    return Promise.reject(new Error(message));
  }
);

// ─── Auth endpoints ──────────────────────────────────────────────────────────
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  logout: () => api.post('/auth/logout'),
  status: () => api.get('/auth/status'),
};

// ─── Validation rule endpoints ───────────────────────────────────────────────
export const rulesAPI = {
  getAll: () => api.get('/validation-rules'),
  toggle: (rules, targetId) => api.post('/validation-rules/toggle', { rules, targetId }),
  enableAll: (rules) => api.post('/validation-rules/enable-all', { rules }),
  disableAll: (rules) => api.post('/validation-rules/disable-all', { rules }),
};

// ─── Deploy endpoint ─────────────────────────────────────────────────────────
export const deployAPI = {
  deploy: (rules) => api.post('/deploy', { rules }),
};

export default api;
