/**
 * useAuth.js
 * Manages Salesforce authentication state across the app.
 */

import { useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api.js';

export function useAuth() {
  const [org, setOrg] = useState(null);
  const [loading, setLoading] = useState(true); // true on first load (checking session)

  // Check if a session already exists on mount
  useEffect(() => {
    authAPI
      .status()
      .then((data) => {
        if (data.authenticated) setOrg(data.org);
      })
      .catch(() => {}) // Unauthenticated — that's fine
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (credentials) => {
    const data = await authAPI.login(credentials);
    setOrg(data.org);
    return data;
  }, []);

  const logout = useCallback(async () => {
    await authAPI.logout();
    setOrg(null);
  }, []);

  return { org, loading, login, logout, isAuthenticated: !!org };
}
