import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import LoadingSpinner from '../components/LoadingSpinner.jsx';
import styles from './LoginPage.module.css';

export default function LoginPage({ onLogin }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: '',
    securityToken: '',
    loginUrl: 'https://login.salesforce.com',
  });
  const [loading, setLoading] = useState(false);
  const [showToken, setShowToken] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username || !form.password) {
      toast.error('Username and password are required.');
      return;
    }
    setLoading(true);
    try {
      await onLogin(form);
      toast.success('Connected to Salesforce!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      {/* Left panel — branding */}
      <div className={styles.brand}>
        <div className={styles.brandInner}>
          <div className={styles.logo}>
            <SalesforceIcon />
          </div>
          <h1 className={styles.brandTitle}>Validation Rule Manager</h1>
          <p className={styles.brandSubtitle}>
            Connect to your Salesforce org and manage Account validation rules
            without ever touching Setup.
          </p>
          <div className={styles.features}>
            {['Tooling API integration', 'Metadata API deployment', 'Bulk enable / disable', 'Real-time status'].map((f) => (
              <div key={f} className={styles.feature}>
                <span className={styles.featureDot} />
                {f}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className={styles.formPanel}>
        <div className={styles.formCard}>
          <div className={styles.formHeader}>
            <h2>Sign in to your org</h2>
            <p>Use your Salesforce Developer Edition credentials</p>
          </div>

          <form onSubmit={handleSubmit} className={styles.form} noValidate>
            <div className={styles.field}>
              <label htmlFor="username">Salesforce Username</label>
              <input
                id="username"
                name="username"
                type="email"
                autoComplete="username"
                placeholder="you@example.com"
                value={form.username}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="securityToken">
                Security Token
                <span className={styles.optional}> — optional</span>
              </label>
              <div className={styles.tokenWrapper}>
                <input
                  id="securityToken"
                  name="securityToken"
                  type={showToken ? 'text' : 'password'}
                  placeholder="Append to password if required"
                  value={form.securityToken}
                  onChange={handleChange}
                  disabled={loading}
                />
                <button
                  type="button"
                  className={styles.toggleVisibility}
                  onClick={() => setShowToken((v) => !v)}
                  aria-label={showToken ? 'Hide token' : 'Show token'}
                >
                  {showToken ? <EyeOffIcon /> : <EyeIcon />}
                </button>
              </div>
              <span className={styles.hint}>
                Found in Salesforce → Settings → Reset My Security Token
              </span>
            </div>

            <div className={styles.field}>
              <label htmlFor="loginUrl">Login URL</label>
              <select
                id="loginUrl"
                name="loginUrl"
                value={form.loginUrl}
                onChange={handleChange}
                disabled={loading}
              >
                <option value="https://login.salesforce.com">
                  Production / Developer Edition
                </option>
                <option value="https://test.salesforce.com">
                  Sandbox
                </option>
              </select>
            </div>

            <button
              type="submit"
              className={styles.submitBtn}
              disabled={loading}
            >
              {loading ? (
                <>
                  <LoadingSpinner size={18} color="white" />
                  Connecting…
                </>
              ) : (
                'Connect to Salesforce'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

// ─── Inline SVG Icons ─────────────────────────────────────────────────────────
function SalesforceIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="40" height="40" rx="10" fill="#0ea5e9" />
      <path d="M20 8C15.58 8 12 11.58 12 16C12 16.74 12.1 17.46 12.28 18.14C11.54 17.72 10.7 17.5 9.8 17.5C7.15 17.5 5 19.65 5 22.3C5 24.95 7.15 27.1 9.8 27.1H29.5C32.54 27.1 35 24.64 35 21.6C35 18.56 32.54 16.1 29.5 16.1C29.4 16.1 29.3 16.1 29.2 16.11C28.58 11.5 24.7 8 20 8Z" fill="white" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  );
}
