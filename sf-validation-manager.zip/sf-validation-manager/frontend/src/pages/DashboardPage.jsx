import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { rulesAPI, deployAPI } from '../services/api.js';
import OrgInfo from '../components/OrgInfo.jsx';
import ValidationRulesTable from '../components/ValidationRulesTable.jsx';
import LoadingSpinner from '../components/LoadingSpinner.jsx';
import DeployStatus from '../components/DeployStatus.jsx';
import styles from './DashboardPage.module.css';

export default function DashboardPage({ org, onLogout }) {
  const [rules, setRules] = useState([]);
  const [filteredRules, setFilteredRules] = useState([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all'); // 'all' | 'active' | 'inactive'
  const [loadingRules, setLoadingRules] = useState(false);
  const [deploying, setDeploying] = useState(false);
  const [deployResult, setDeployResult] = useState(null);
  const [hasUnsaved, setHasUnsaved] = useState(false);

  // ─── Fetch Rules ────────────────────────────────────────────────────────────
  const fetchRules = useCallback(async () => {
    setLoadingRules(true);
    setDeployResult(null);
    try {
      const data = await rulesAPI.getAll();
      setRules(data.data);
      setHasUnsaved(false);
    } catch (err) {
      toast.error(err.message || 'Failed to fetch validation rules.');
    } finally {
      setLoadingRules(false);
    }
  }, []);

  // ─── Filter / Search ────────────────────────────────────────────────────────
  useEffect(() => {
    let result = [...rules];
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          (r.description || '').toLowerCase().includes(q)
      );
    }
    if (filterStatus === 'active') result = result.filter((r) => r.active);
    if (filterStatus === 'inactive') result = result.filter((r) => !r.active);
    setFilteredRules(result);
  }, [rules, search, filterStatus]);

  // ─── Toggle Single Rule ─────────────────────────────────────────────────────
  const handleToggle = async (targetId) => {
    try {
      const data = await rulesAPI.toggle(rules, targetId);
      setRules(data.data);
      setHasUnsaved(true);
    } catch (err) {
      toast.error(err.message);
    }
  };

  // ─── Enable All ─────────────────────────────────────────────────────────────
  const handleEnableAll = async () => {
    try {
      const data = await rulesAPI.enableAll(rules);
      setRules(data.data);
      setHasUnsaved(true);
      toast.success('All rules marked as active. Deploy to apply changes.');
    } catch (err) {
      toast.error(err.message);
    }
  };

  // ─── Disable All ────────────────────────────────────────────────────────────
  const handleDisableAll = async () => {
    try {
      const data = await rulesAPI.disableAll(rules);
      setRules(data.data);
      setHasUnsaved(true);
      toast.success('All rules marked as inactive. Deploy to apply changes.');
    } catch (err) {
      toast.error(err.message);
    }
  };

  // ─── Deploy ─────────────────────────────────────────────────────────────────
  const handleDeploy = async () => {
    if (!hasUnsaved) {
      toast('No pending changes to deploy.', { icon: 'ℹ️' });
      return;
    }
    setDeploying(true);
    setDeployResult(null);
    try {
      const result = await deployAPI.deploy(rules);
      setDeployResult({ success: true, ...result });
      setHasUnsaved(false);
      toast.success('Deployment succeeded!');
    } catch (err) {
      setDeployResult({ success: false, message: err.message });
      toast.error('Deployment failed. See details below.');
    } finally {
      setDeploying(false);
    }
  };

  // ─── Logout ──────────────────────────────────────────────────────────────────
  const handleLogout = async () => {
    try {
      await onLogout();
    } catch {
      // ignore
    }
  };

  const activeCount = rules.filter((r) => r.active).length;
  const inactiveCount = rules.length - activeCount;

  return (
    <div className={styles.page}>
      {/* ── Sidebar ─────────────────────────────────────────────────────────── */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarLogo}>
          <CloudIcon />
          <span>SF Validation Manager</span>
        </div>

        <nav className={styles.nav}>
          <div className={styles.navItem + ' ' + styles.navItemActive}>
            <ShieldIcon />
            <span>Validation Rules</span>
          </div>
        </nav>

        <div className={styles.sidebarFooter}>
          <OrgInfo org={org} />
          <button className={styles.logoutBtn} onClick={handleLogout}>
            <LogOutIcon />
            <span>Disconnect</span>
          </button>
        </div>
      </aside>

      {/* ── Main Content ─────────────────────────────────────────────────────── */}
      <main className={styles.main}>
        {/* Header */}
        <div className={styles.header}>
          <div>
            <h1 className={styles.title}>Validation Rules</h1>
            <p className={styles.subtitle}>Account object — {org?.instanceUrl}</p>
          </div>

          <div className={styles.headerActions}>
            {hasUnsaved && (
              <span className={styles.unsavedBadge}>● Unsaved changes</span>
            )}

            <button
              className={styles.btnSecondary}
              onClick={fetchRules}
              disabled={loadingRules}
            >
              {loadingRules ? <LoadingSpinner size={16} /> : <RefreshIcon />}
              Get Metadata
            </button>

            <button
              className={styles.btnSuccess}
              onClick={handleEnableAll}
              disabled={loadingRules || rules.length === 0}
            >
              <CheckAllIcon />
              Enable All
            </button>

            <button
              className={styles.btnDanger}
              onClick={handleDisableAll}
              disabled={loadingRules || rules.length === 0}
            >
              <XAllIcon />
              Disable All
            </button>

            <button
              className={styles.btnPrimary}
              onClick={handleDeploy}
              disabled={deploying || !hasUnsaved}
            >
              {deploying ? <LoadingSpinner size={16} color="white" /> : <DeployIcon />}
              {deploying ? 'Deploying…' : 'Deploy Changes'}
            </button>
          </div>
        </div>

        {/* Stats Row */}
        {rules.length > 0 && (
          <div className={styles.statsRow}>
            <StatCard label="Total Rules" value={rules.length} color="accent" />
            <StatCard label="Active" value={activeCount} color="success" />
            <StatCard label="Inactive" value={inactiveCount} color="muted" />
            <StatCard
              label="Filtered"
              value={filteredRules.length}
              color="warning"
            />
          </div>
        )}

        {/* Deploy Status */}
        {deployResult && (
          <DeployStatus result={deployResult} onDismiss={() => setDeployResult(null)} />
        )}

        {/* Search & Filter */}
        {rules.length > 0 && (
          <div className={styles.toolbar}>
            <div className={styles.searchWrapper}>
              <SearchIcon />
              <input
                type="text"
                placeholder="Search by name or description…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className={styles.searchInput}
              />
              {search && (
                <button
                  className={styles.clearSearch}
                  onClick={() => setSearch('')}
                  aria-label="Clear search"
                >
                  ×
                </button>
              )}
            </div>

            <div className={styles.filterTabs}>
              {[
                { value: 'all', label: 'All' },
                { value: 'active', label: 'Active' },
                { value: 'inactive', label: 'Inactive' },
              ].map((tab) => (
                <button
                  key={tab.value}
                  className={`${styles.filterTab} ${filterStatus === tab.value ? styles.filterTabActive : ''}`}
                  onClick={() => setFilterStatus(tab.value)}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Empty / Loading State */}
        {!loadingRules && rules.length === 0 && (
          <div className={styles.emptyState}>
            <ShieldIcon size={48} />
            <h3>No validation rules loaded</h3>
            <p>Click <strong>Get Metadata</strong> to fetch validation rules from your org.</p>
            <button className={styles.btnPrimary} onClick={fetchRules}>
              <RefreshIcon />
              Get Metadata
            </button>
          </div>
        )}

        {loadingRules && (
          <div className={styles.loadingState}>
            <LoadingSpinner size={36} />
            <p>Fetching validation rules from Salesforce…</p>
          </div>
        )}

        {/* Rules Table */}
        {!loadingRules && rules.length > 0 && (
          <ValidationRulesTable
            rules={filteredRules}
            onToggle={handleToggle}
          />
        )}
      </main>
    </div>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ label, value, color }) {
  const colorMap = {
    accent: 'var(--accent)',
    success: 'var(--success)',
    muted: 'var(--text-muted)',
    warning: 'var(--warning)',
  };
  return (
    <div className={styles.statCard}>
      <span className={styles.statValue} style={{ color: colorMap[color] }}>
        {value}
      </span>
      <span className={styles.statLabel}>{label}</span>
    </div>
  );
}

// ─── Icons ────────────────────────────────────────────────────────────────────
function CloudIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
      <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
    </svg>
  );
}
function ShieldIcon({ size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>
  );
}
function RefreshIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
    </svg>
  );
}
function CheckAllIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  );
}
function XAllIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
  );
}
function DeployIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/>
      <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
    </svg>
  );
}
function LogOutIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
      <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
  );
}
function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
  );
}
