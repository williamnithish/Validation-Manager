import React from 'react';
import styles from './OrgInfo.module.css';

export default function OrgInfo({ org }) {
  if (!org) return null;

  const domain = org.instanceUrl?.replace('https://', '').split('.')[0] || 'Unknown';

  return (
    <div className={styles.card}>
      <div className={styles.avatar}>{domain.slice(0, 2).toUpperCase()}</div>
      <div className={styles.info}>
        <span className={styles.username} title={org.username}>
          {org.username}
        </span>
        <span className={styles.orgId} title={org.orgId}>
          {org.orgId}
        </span>
      </div>
      <span className={styles.connectedDot} title="Connected" />
    </div>
  );
}
