import React, { useState } from 'react';
import styles from './ValidationRulesTable.module.css';
import Toggle from './Toggle.jsx';

export default function ValidationRulesTable({ rules, onToggle }) {
  const [expandedId, setExpandedId] = useState(null);

  if (rules.length === 0) {
    return (
      <div className={styles.noResults}>
        <p>No rules match your search or filter.</p>
      </div>
    );
  }

  return (
    <div className={styles.tableWrapper}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Rule Name</th>
            <th>Rule ID</th>
            <th>Status</th>
            <th>Last Modified</th>
            <th>Modified By</th>
            <th>Toggle</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rules.map((rule) => (
            <React.Fragment key={rule.id}>
              <tr className={`${styles.row} ${expandedId === rule.id ? styles.rowExpanded : ''}`}>
                {/* Rule Name */}
                <td>
                  <div className={styles.ruleName}>
                    <span className={`${styles.statusDot} ${rule.active ? styles.dotActive : styles.dotInactive}`} />
                    <span className={styles.nameText}>{rule.name}</span>
                  </div>
                </td>

                {/* Rule ID */}
                <td>
                  <span className={styles.ruleId} title={rule.id}>
                    {rule.id.slice(0, 15)}…
                  </span>
                </td>

                {/* Status Badge */}
                <td>
                  <span className={`${styles.badge} ${rule.active ? styles.badgeActive : styles.badgeInactive}`}>
                    {rule.active ? 'Active' : 'Inactive'}
                  </span>
                </td>

                {/* Last Modified Date */}
                <td>
                  <span className={styles.date}>{formatDate(rule.lastModifiedDate)}</span>
                </td>

                {/* Modified By */}
                <td>
                  <span className={styles.modifiedBy}>{rule.lastModifiedBy}</span>
                </td>

                {/* Toggle */}
                <td>
                  <Toggle
                    checked={rule.active}
                    onChange={() => onToggle(rule.id)}
                    label={`Toggle ${rule.name}`}
                  />
                </td>

                {/* Actions */}
                <td>
                  <button
                    className={styles.detailsBtn}
                    onClick={() =>
                      setExpandedId((prev) => (prev === rule.id ? null : rule.id))
                    }
                    aria-expanded={expandedId === rule.id}
                  >
                    {expandedId === rule.id ? 'Hide' : 'Details'}
                    <ChevronIcon rotated={expandedId === rule.id} />
                  </button>
                </td>
              </tr>

              {/* Expanded Details Row */}
              {expandedId === rule.id && (
                <tr className={styles.detailsRow}>
                  <td colSpan={7}>
                    <div className={styles.detailsPanel}>
                      <DetailGrid rule={rule} />
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Detail Grid ──────────────────────────────────────────────────────────────
function DetailGrid({ rule }) {
  return (
    <div className={styles.detailGrid}>
      <DetailItem label="Full Rule ID" value={rule.id} mono />
      <DetailItem label="Error Condition Formula" value={rule.errorConditionFormula || '(none)'} mono />
      <DetailItem label="Description" value={rule.description || '(none)'} />
      <DetailItem label="Error Message" value={rule.errorMessage || '(none)'} />
      <DetailItem label="Error Display Field" value={rule.errorDisplayField || '(none)'} />
      <DetailItem label="Created Date" value={formatDate(rule.createdDate)} />
      <DetailItem label="Created By" value={rule.createdBy} />
      <DetailItem label="Last Modified" value={formatDate(rule.lastModifiedDate)} />
      <DetailItem label="Last Modified By" value={rule.lastModifiedBy} />
    </div>
  );
}

function DetailItem({ label, value, mono }) {
  return (
    <div className={styles.detailItem}>
      <span className={styles.detailLabel}>{label}</span>
      <span className={`${styles.detailValue} ${mono ? styles.detailMono : ''}`}>{value}</span>
    </div>
  );
}

// ─── Icon ─────────────────────────────────────────────────────────────────────
function ChevronIcon({ rotated }) {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      style={{ transform: rotated ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}
