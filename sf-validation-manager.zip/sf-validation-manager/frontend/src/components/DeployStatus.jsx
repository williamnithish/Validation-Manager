import React from 'react';
import styles from './DeployStatus.module.css';

export default function DeployStatus({ result, onDismiss }) {
  const isSuccess = result.success;

  return (
    <div className={`${styles.banner} ${isSuccess ? styles.success : styles.error}`}>
      <div className={styles.iconWrapper}>
        {isSuccess ? <CheckCircleIcon /> : <AlertCircleIcon />}
      </div>

      <div className={styles.content}>
        <h4>{isSuccess ? 'Deployment Successful' : 'Deployment Failed'}</h4>
        <p>{result.message}</p>

        {isSuccess && (
          <div className={styles.metaRow}>
            <span>Deployment ID: <code>{result.deploymentId}</code></span>
            <span>Components Deployed: <code>{result.deployed}</code></span>
          </div>
        )}

        {!isSuccess && result.errors?.length > 0 && (
          <ul className={styles.errorList}>
            {result.errors.map((e, i) => (
              <li key={i}>
                <strong>{e.component}</strong>: {e.problem}
              </li>
            ))}
          </ul>
        )}
      </div>

      <button className={styles.dismissBtn} onClick={onDismiss} aria-label="Dismiss">
        ×
      </button>
    </div>
  );
}

function CheckCircleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10"/><polyline points="9 12 12 15 16 10"/>
    </svg>
  );
}

function AlertCircleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
  );
}
