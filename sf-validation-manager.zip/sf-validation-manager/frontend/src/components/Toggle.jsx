import React from 'react';
import styles from './Toggle.module.css';

export default function Toggle({ checked, onChange, label }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`${styles.toggle} ${checked ? styles.toggleOn : ''}`}
      onClick={onChange}
    >
      <span className={styles.thumb} />
    </button>
  );
}
