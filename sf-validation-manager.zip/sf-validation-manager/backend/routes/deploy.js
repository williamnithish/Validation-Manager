import { Router } from 'express';
import { deploy } from '../controllers/deployController.js';

const router = Router();

router.post('/', deploy);

export default router;
