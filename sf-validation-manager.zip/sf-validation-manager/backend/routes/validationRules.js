import { Router } from 'express';
import {
  getValidationRules,
  toggleRule,
  enableAll,
  disableAll,
} from '../controllers/validationRulesController.js';

const router = Router();

router.get('/', getValidationRules);
router.post('/toggle', toggleRule);
router.post('/enable-all', enableAll);
router.post('/disable-all', disableAll);

export default router;
