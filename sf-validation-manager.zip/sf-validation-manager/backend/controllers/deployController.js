/**
 * deployController.js
 * Handles Metadata API deployments of validation rule changes.
 */

import { deployValidationRules } from '../services/salesforceService.js';

/**
 * POST /api/deploy
 * Deploys the provided validation rules to the connected Salesforce org.
 *
 * Body: { rules: [{ name, active, errorConditionFormula, errorMessage }] }
 *
 * How it works:
 * 1. Receives the full rules array from the client (with modified active flags).
 * 2. Builds a Metadata API deployment package (zip with package.xml + Account.object).
 * 3. Submits the zip via SOAP to /services/Soap/m/XX.0.
 * 4. Polls checkDeployStatus until completion.
 * 5. Returns success/failure with any component errors.
 */
export async function deploy(req, res, next) {
  try {
    const { rules } = req.body;
    const { accessToken, instanceUrl } = req.session.salesforce;

    if (!rules || !Array.isArray(rules) || rules.length === 0) {
      return res.status(400).json({
        error: 'ValidationError',
        message: 'A non-empty `rules` array is required.',
      });
    }

    const invalidRule = rules.find(
      (r) => !r || typeof r.name !== 'string' || !r.name.trim() || typeof r.active !== 'boolean'
    );
    if (invalidRule) {
      return res.status(400).json({
        error: 'ValidationError',
        message: 'Each rule must include a non-empty `name` (string) and `active` (boolean) field.',
      });
    }

    const result = await deployValidationRules(accessToken, instanceUrl, rules);

    res.json({
      success: true,
      message: `Deployment succeeded. ${result.numberComponentsDeployed} component(s) deployed.`,
      deploymentId: result.id,
      status: result.status,
      deployed: result.numberComponentsDeployed,
      errors: result.numberComponentErrors,
    });
  } catch (err) {
    // Deployment failures are not 500 errors — surface them clearly
    if (err.deployStatus) {
      return res.status(400).json({
        error: 'DeploymentFailed',
        message: err.message,
        status: err.deployStatus,
        errors: err.errors || [],
      });
    }
    next(err);
  }
}
