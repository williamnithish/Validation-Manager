/**
 * authController.js
 * Handles login, logout, and session status endpoints.
 */

import { authenticateUser } from '../services/salesforceService.js';

/**
 * POST /api/auth/login
 * Authenticates the user against their Salesforce org and stores
 * the session token server-side (never exposed to the client).
 */
export async function login(req, res, next) {
  try {
    const { username, password, securityToken, loginUrl } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        error: 'ValidationError',
        message: 'Username and password are required.',
      });
    }

    const { userInfo, accessToken, instanceUrl } = await authenticateUser(
      username,
      password,
      securityToken || '',
      loginUrl || process.env.SF_LOGIN_URL
    );

    // Store session on the server – access token is never sent to the browser
    req.session.salesforce = {
      accessToken,
      instanceUrl,
      userId: userInfo.id,
      orgId: userInfo.organizationId,
      username,
    };

    // Save session before responding
    await new Promise((resolve, reject) =>
      req.session.save((err) => (err ? reject(err) : resolve()))
    );

    res.json({
      success: true,
      message: 'Successfully connected to Salesforce.',
      org: {
        instanceUrl,
        userId: userInfo.id,
        orgId: userInfo.organizationId,
        username,
      },
    });
  } catch (err) {
    // Surface Salesforce login errors clearly
    if (err.message?.includes('INVALID_LOGIN')) {
      return res.status(401).json({
        error: 'InvalidCredentials',
        message: 'Invalid username, password, or security token. Please check your credentials.',
      });
    }
    next(err);
  }
}

/**
 * POST /api/auth/logout
 * Destroys the server-side session.
 */
export async function logout(req, res, next) {
  try {
    await new Promise((resolve, reject) =>
      req.session.destroy((err) => (err ? reject(err) : resolve()))
    );
    res.clearCookie('connect.sid');
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/auth/status
 * Returns current session info (non-sensitive) for the frontend.
 */
export function status(req, res) {
  if (!req.session?.salesforce) {
    return res.json({ authenticated: false });
  }

  const { instanceUrl, orgId, username } = req.session.salesforce;
  res.json({
    authenticated: true,
    org: { instanceUrl, orgId, username },
  });
}
