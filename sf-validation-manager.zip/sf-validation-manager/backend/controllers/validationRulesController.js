/**
 * validationRulesController.js
 * Handles fetching and in-memory toggling of Salesforce validation rules.
 * Actual Salesforce changes are applied via the /deploy endpoint.
 */

import { fetchValidationRules } from '../services/salesforceService.js';

/**
 * GET /api/validation-rules
 * Fetches all Account validation rules via the Tooling API.
 */
export async function getValidationRules(req, res, next) {
  try {
    const { accessToken, instanceUrl } = req.session.salesforce;
    const rules = await fetchValidationRules(accessToken, instanceUrl);
    res.json({ success: true, data: rules, count: rules.length });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/validation-rules/toggle
 * Returns a toggled version of the rules array (no Salesforce call—client manages state).
 * Body: { rules: [...], targetId: string }
 */
export function toggleRule(req, res) {
  const { rules, targetId } = req.body;

  if (!rules || !targetId) {
    return res.status(400).json({
      error: 'ValidationError',
      message: '`rules` array and `targetId` are required.',
    });
  }

  const updated = rules.map((rule) =>
    rule.id === targetId ? { ...rule, active: !rule.active } : rule
  );

  res.json({ success: true, data: updated });
}

/**
 * POST /api/validation-rules/enable-all
 * Returns rules with all active flags set to true.
 * Body: { rules: [...] }
 */
export function enableAll(req, res) {
  const { rules } = req.body;
  if (!rules) {
    return res.status(400).json({ error: 'ValidationError', message: '`rules` array is required.' });
  }
  const updated = rules.map((r) => ({ ...r, active: true }));
  res.json({ success: true, data: updated });
}

/**
 * POST /api/validation-rules/disable-all
 * Returns rules with all active flags set to false.
 * Body: { rules: [...] }
 */
export function disableAll(req, res) {
  const { rules } = req.body;
  if (!rules) {
    return res.status(400).json({ error: 'ValidationError', message: '`rules` array is required.' });
  }
  const updated = rules.map((r) => ({ ...r, active: false }));
  res.json({ success: true, data: updated });
}
