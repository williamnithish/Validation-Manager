/**
 * salesforceService.js
 *
 * Core Salesforce integration layer.
 * Handles authentication, Tooling API queries, and Metadata API deployments.
 */

import jsforce from 'jsforce';
import axios from 'axios';
import { parseStringPromise } from 'xml2js';
import { buildDeploymentZip } from '../utils/zipBuilder.js';

// ─── Authentication ───────────────────────────────────────────────────────────

/**
 * Authenticates a user against Salesforce using username + password + token.
 * Returns the connection object and user info.
 *
 * @param {string} username
 * @param {string} password
 * @param {string} securityToken - Optional. Appended to password if provided.
 * @param {string} loginUrl - e.g. https://login.salesforce.com
 */
export async function authenticateUser(username, password, securityToken = '', loginUrl) {
  const conn = new jsforce.Connection({
    loginUrl: loginUrl || process.env.SF_LOGIN_URL || 'https://login.salesforce.com',
  });

  // Salesforce requires password+token concatenated when security token is used
  const fullPassword = securityToken ? `${password}${securityToken}` : password;

  const userInfo = await conn.login(username, fullPassword);

  return {
    conn,
    userInfo,
    accessToken: conn.accessToken,
    instanceUrl: conn.instanceUrl,
  };
}

// ─── Tooling API ──────────────────────────────────────────────────────────────

/**
 * Fetches all ValidationRule records on the Account object using the Tooling API.
 * Tooling API endpoint: /services/data/vXX.0/tooling/query?q=SOQL
 *
 * @param {string} accessToken
 * @param {string} instanceUrl
 */
export async function fetchValidationRules(accessToken, instanceUrl) {
  const apiVersion = 'v59.0';

  // SOQL query against Tooling API – ValidationRule entity
  const soql = `
    SELECT
      Id,
      ValidationName,
      Active,
      Description,
      ErrorMessage,
      ErrorDisplayField,
      ErrorConditionFormula,
      EntityDefinitionId,
      CreatedDate,
      LastModifiedDate,
      CreatedBy.Name,
      LastModifiedBy.Name
    FROM ValidationRule
    WHERE EntityDefinition.QualifiedApiName = 'Account'
    ORDER BY ValidationName ASC
  `.trim().replace(/\s+/g, ' ');

  const url = `${instanceUrl}/services/data/${apiVersion}/tooling/query?q=${encodeURIComponent(soql)}`;

  const response = await axios.get(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
  });

  const rules = response.data.records.map((rule) => ({
    id: rule.Id,
    name: rule.ValidationName,
    active: rule.Active,
    description: rule.Description || '',
    errorMessage: rule.ErrorMessage || '',
    errorDisplayField: rule.ErrorDisplayField || '',
    errorConditionFormula: rule.ErrorConditionFormula || '',
    entityDefinitionId: rule.EntityDefinitionId,
    createdDate: rule.CreatedDate,
    lastModifiedDate: rule.LastModifiedDate,
    createdBy: rule.CreatedBy?.Name || 'Unknown',
    lastModifiedBy: rule.LastModifiedBy?.Name || 'Unknown',
  }));

  return rules;
}

// ─── Metadata API Deployment ──────────────────────────────────────────────────

/**
 * Deploys updated validation rule active statuses to Salesforce via Metadata API.
 *
 * How it works:
 * 1. Build a package.xml + per-rule XML metadata file inside a zip buffer.
 * 2. POST the zip to /services/Soap/m/XX.0 (Metadata API SOAP endpoint) as a deploy request.
 * 3. Poll the deployment status until it completes or fails.
 *
 * @param {string} accessToken
 * @param {string} instanceUrl
 * @param {Array} rules - Array of { name, active } objects to deploy
 */
export async function deployValidationRules(accessToken, instanceUrl, rules) {
  const apiVersion = '59.0';
  const metadataUrl = `${instanceUrl}/services/Soap/m/${apiVersion}`;

  // Step 1: Build zip containing metadata
  const zipBuffer = await buildDeploymentZip(rules, apiVersion);
  const zipBase64 = zipBuffer.toString('base64');

  // Step 2: Send deploy SOAP request
  const deploySoap = buildDeploySoapEnvelope(accessToken, zipBase64);

  const deployResponse = await axios.post(metadataUrl, deploySoap, {
    headers: {
      'Content-Type': 'text/xml',
      SOAPAction: 'deploy',
    },
  });

  const parsedDeploy = await parseStringPromise(deployResponse.data, { explicitArray: false });
  const deployBody = parsedDeploy['soapenv:Envelope']['soapenv:Body'];
  const asyncId = deployBody['deployResponse']['result']['id'];

  if (!asyncId) {
    throw new Error('Failed to initiate deployment: no async process ID returned.');
  }

  // Step 3: Poll until complete
  const result = await pollDeployStatus(accessToken, instanceUrl, asyncId, apiVersion);
  return result;
}

/**
 * Polls the Metadata API until the deployment finishes.
 */
async function pollDeployStatus(accessToken, instanceUrl, asyncId, apiVersion) {
  const metadataUrl = `${instanceUrl}/services/Soap/m/${apiVersion}`;
  const maxAttempts = 30;
  const pollInterval = 3000; // 3 seconds

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    await sleep(pollInterval);

    const statusSoap = buildCheckStatusSoapEnvelope(accessToken, asyncId);
    const statusResponse = await axios.post(metadataUrl, statusSoap, {
      headers: {
        'Content-Type': 'text/xml',
        SOAPAction: 'checkDeployStatus',
      },
    });

    const parsed = await parseStringPromise(statusResponse.data, { explicitArray: false });
    const result = parsed['soapenv:Envelope']['soapenv:Body']['checkDeployStatusResponse']['result'];

    const state = result.status;
    const done = result.done === 'true' || result.done === true;

    if (done) {
      if (state === 'Succeeded') {
        return {
          success: true,
          status: state,
          id: asyncId,
          numberComponentsDeployed: result.numberComponentsDeployed || 0,
          numberComponentErrors: result.numberComponentErrors || 0,
          details: result.details || null,
        };
      } else {
        // Extract component errors if available
        const errors = extractDeployErrors(result);
        throw Object.assign(new Error(`Deployment ${state}.`), {
          statusCode: 400,
          deployStatus: state,
          errors,
        });
      }
    }

    console.log(`⏳ Deploy status [attempt ${attempt + 1}]: ${state}`);
  }

  throw new Error('Deployment timed out after polling limit was reached.');
}

// ─── SOAP Envelope Builders ───────────────────────────────────────────────────

function buildDeploySoapEnvelope(accessToken, zipBase64) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:met="http://soap.sforce.com/2006/04/metadata">
  <soapenv:Header>
    <met:CallOptions></met:CallOptions>
    <met:SessionHeader>
      <met:sessionId>${accessToken}</met:sessionId>
    </met:SessionHeader>
  </soapenv:Header>
  <soapenv:Body>
    <met:deploy>
      <met:ZipFile>${zipBase64}</met:ZipFile>
      <met:DeployOptions>
        <met:allowMissingFiles>false</met:allowMissingFiles>
        <met:autoUpdatePackage>false</met:autoUpdatePackage>
        <met:checkOnly>false</met:checkOnly>
        <met:ignoreWarnings>false</met:ignoreWarnings>
        <met:performRetrieve>false</met:performRetrieve>
        <met:purgeOnDelete>false</met:purgeOnDelete>
        <met:rollbackOnError>true</met:rollbackOnError>
        <met:runAllTests>false</met:runAllTests>
        <met:singlePackage>true</met:singlePackage>
      </met:DeployOptions>
    </met:deploy>
  </soapenv:Body>
</soapenv:Envelope>`;
}

function buildCheckStatusSoapEnvelope(accessToken, asyncId) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:met="http://soap.sforce.com/2006/04/metadata">
  <soapenv:Header>
    <met:SessionHeader>
      <met:sessionId>${accessToken}</met:sessionId>
    </met:SessionHeader>
  </soapenv:Header>
  <soapenv:Body>
    <met:checkDeployStatus>
      <met:asyncProcessId>${asyncId}</met:asyncProcessId>
      <met:includeDetails>true</met:includeDetails>
    </met:checkDeployStatus>
  </soapenv:Body>
</soapenv:Envelope>`;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractDeployErrors(result) {
  try {
    const details = result.details;
    if (!details) return [];
    const failures = details.componentFailures;
    if (!failures) return [];
    const arr = Array.isArray(failures) ? failures : [failures];
    return arr.map((f) => ({
      component: f.fullName,
      problem: f.problem,
      problemType: f.problemType,
    }));
  } catch {
    return [];
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
