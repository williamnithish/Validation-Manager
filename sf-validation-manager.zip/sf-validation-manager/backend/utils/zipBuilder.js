/**
 * zipBuilder.js
 *
 * Builds the deployment zip file required by the Salesforce Metadata API.
 *
 * Zip structure:
 *   package.xml
 *   objects/
 *     Account.object   ← Contains all ValidationRule metadata for Account
 *
 * Note: ValidationRules are child metadata of CustomObject, so they are
 * embedded inside the Account.object XML file, NOT as separate files.
 */

import { createHash } from 'crypto';

/**
 * Builds a zip Buffer containing the Metadata API deployment package.
 *
 * @param {Array} rules - Array of { name: string, active: boolean }
 * @param {string} apiVersion - e.g. '59.0'
 * @returns {Promise<Buffer>} zip file buffer
 */
export async function buildDeploymentZip(rules, apiVersion) {
  // Dynamically import JSZip (ESM compatible)
  const { default: JSZip } = await import('jszip');

  const zip = new JSZip();

  // ─── package.xml ──────────────────────────────────────────────────────────
  const packageXml = buildPackageXml(apiVersion);
  zip.file('package.xml', packageXml);

  // ─── Account.object ───────────────────────────────────────────────────────
  // Each validation rule is a child element inside CustomObject metadata
  const accountObjectXml = buildAccountObjectXml(rules);
  zip.file('objects/Account.object', accountObjectXml);

  // Generate zip as Node.js Buffer
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  return buffer;
}

// ─── XML Builders ─────────────────────────────────────────────────────────────

/**
 * Builds the package.xml manifest that tells Salesforce what to deploy.
 */
function buildPackageXml(apiVersion) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>Account</members>
        <name>CustomObject</name>
    </types>
    <version>${apiVersion}</version>
</Package>`;
}

/**
 * Builds Account.object XML containing all validation rule updates.
 *
 * Only the <active> flag is sent — Salesforce merges it with the existing
 * definition rather than replacing the entire rule. All other rule fields
 * (errorConditionFormula, errorMessage, etc.) are preserved in the org.
 */
function buildAccountObjectXml(rules) {
  const rulesXml = rules
    .map(
      (rule) => `
    <validationRules>
        <fullName>${escapeXml(rule.name)}</fullName>
        <active>${rule.active}</active>
        <errorConditionFormula>${escapeXml(rule.errorConditionFormula || 'true')}</errorConditionFormula>
        <errorMessage>${escapeXml(rule.errorMessage || 'Validation error')}</errorMessage>
    </validationRules>`
    )
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
${rulesXml}
</CustomObject>`;
}

/**
 * Escapes special XML characters.
 */
function escapeXml(str) {
  if (typeof str !== 'string') return String(str ?? '');
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
