/**
 * requireAuth middleware
 * Protects routes by verifying an active Salesforce session exists.
 */

export const requireAuth = (req, res, next) => {
  if (!req.session || !req.session.salesforce) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'You must be logged in to access this resource.',
    });
  }
  next();
};
