/**
 * Global error handling middleware.
 * Catches all errors thrown in route handlers and formats a consistent response.
 */

export const errorHandler = (err, req, res, next) => {
  console.error('❌ Error:', err.message || err);

  // Salesforce / jsforce errors often have a specific shape
  if (err.errorCode) {
    return res.status(400).json({
      error: err.errorCode,
      message: err.message,
    });
  }

  // Axios errors from direct Salesforce REST calls
  if (err.response) {
    const { status, data } = err.response;
    return res.status(status || 500).json({
      error: 'SalesforceAPIError',
      message: data?.message || data?.[0]?.message || 'Salesforce API request failed.',
      details: data,
    });
  }

  const statusCode = err.statusCode || err.status || 500;
  res.status(statusCode).json({
    error: err.name || 'InternalServerError',
    message: err.message || 'An unexpected error occurred.',
  });
};
