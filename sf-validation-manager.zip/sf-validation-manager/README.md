# Salesforce Validation Rule Manager

A full-stack web application for dynamically connecting to any Salesforce Developer Edition org and managing **Account object Validation Rules** — view, search, toggle, bulk enable/disable, and deploy changes back to Salesforce via the Metadata API.

![Tech](https://img.shields.io/badge/stack-React%20%2B%20Node.js-0ea5e9)
![API](https://img.shields.io/badge/salesforce-Tooling%20%2B%20Metadata%20API-00a1e0)

---

## Table of Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Prerequisites](#prerequisites)
5. [Local Setup](#local-setup)
6. [Salesforce Setup Guide](#salesforce-setup-guide)
7. [How It Works](#how-it-works)
8. [API Reference](#api-reference)
9. [Deployment Guide](#deployment-guide)
10. [Security Notes](#security-notes)
11. [Troubleshooting](#troubleshooting)

---

## Features

- 🔐 **Dynamic login** to any Salesforce org — no hardcoded credentials, org IDs, or rule names
- 📋 **Live metadata fetch** of all Account validation rules via the Tooling API
- 🔁 **Per-rule toggle**, plus **Enable All** / **Disable All** bulk actions
- 🚀 **One-click deploy** of changes back to Salesforce using the Metadata API (real SOAP deploy + polling)
- 🔍 Search and status filtering (All / Active / Inactive)
- 📊 Live stats (total / active / inactive / filtered counts)
- 🔔 Toast notifications, inline deployment status banners, loading states
- 📱 Fully responsive, modern dark UI
- 🛡️ Session-based auth — Salesforce access tokens never reach the browser

---

## Architecture

```
┌─────────────────┐        HTTPS (session cookie)        ┌──────────────────┐
│   React (Vite)   │ ────────────────────────────────────▶│  Node / Express   │
│   Frontend       │◀──────────────────────────────────── │  Backend API      │
└─────────────────┘            JSON responses              └────────┬─────────┘
                                                                      │
                                                       Tooling API /  │  Metadata API
                                                       REST + SOAP    │
                                                                      ▼
                                                            ┌──────────────────┐
                                                            │  Salesforce Org   │
                                                            │ (Developer Ed.)   │
                                                            └──────────────────┘
```

- The **frontend never talks to Salesforce directly** — it always goes through the backend.
- The backend authenticates with Salesforce using `jsforce`, then stores the resulting `accessToken` + `instanceUrl` in a **server-side session** (never sent to the client).
- All Salesforce API calls (Tooling API queries, Metadata API deploys) happen server-side.

---

## Project Structure

```
sf-validation-manager/
├── backend/
│   ├── controllers/        # Request handlers (auth, rules, deploy)
│   ├── routes/              # Express route definitions
│   ├── services/            # Salesforce integration (jsforce, Tooling/Metadata API)
│   ├── middleware/           # requireAuth, errorHandler
│   ├── utils/                # zipBuilder (Metadata API deployment package)
│   ├── server.js             # Express app entry point
│   ├── package.json
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── pages/            # LoginPage, DashboardPage
│   │   ├── components/       # ValidationRulesTable, Toggle, OrgInfo, DeployStatus, LoadingSpinner
│   │   ├── services/         # api.js (Axios client)
│   │   ├── hooks/             # useAuth.js
│   │   ├── styles/            # global.css (design tokens)
│   │   └── App.jsx
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   └── .env.example
│
├── docs/
│   ├── SALESFORCE_SETUP.md
│   ├── DEPLOYMENT.md
│   └── API.md
│
└── README.md
```

---

## Prerequisites

- **Node.js** v18 or later
- **npm** v9 or later
- A **Salesforce Developer Edition** org ([sign up free](https://developer.salesforce.com/signup))
- At least one **custom validation rule on the Account object** in that org (see [Salesforce Setup Guide](#salesforce-setup-guide))

---

## Local Setup

### 1. Clone and install

```bash
git clone <your-repo-url>
cd sf-validation-manager

# Backend
cd backend
npm install
cp .env.example .env

# Frontend
cd ../frontend
npm install
cp .env.example .env
```

### 2. Configure environment variables

**backend/.env**
```env
PORT=5000
NODE_ENV=development
SESSION_SECRET=replace-with-a-long-random-string
FRONTEND_URL=http://localhost:5173
SF_LOGIN_URL=https://login.salesforce.com
```

> Generate a strong session secret:
> `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

**frontend/.env** — not required for local dev (Vite proxies `/api` to `localhost:5000` automatically). Only set `VITE_API_URL` when deploying to production.

### 3. Run both servers

```bash
# Terminal 1
cd backend
npm run dev          # nodemon, auto-restarts on change

# Terminal 2
cd frontend
npm run dev          # Vite dev server on http://localhost:5173
```

Open **http://localhost:5173**, log in with your Salesforce Developer Edition credentials, and you're in.

---

## Salesforce Setup Guide

See [`docs/SALESFORCE_SETUP.md`](docs/SALESFORCE_SETUP.md) for full step-by-step instructions on:
- Creating a Developer Edition org
- Creating sample Account validation rules
- Retrieving your security token
- Required user permissions (API Enabled, Modify Metadata, Customize Application)

---

## How It Works

### 1. Authentication
The frontend posts `username`, `password`, and optional `securityToken` to `POST /api/auth/login`. The backend uses **jsforce** to call Salesforce's SOAP login API (`conn.login()`), which returns an `accessToken` and `instanceUrl`. These are stored in an **httpOnly server-side session** — the browser only ever receives a session cookie, never the actual Salesforce token.

### 2. Fetching Validation Rules (Tooling API)
`GET /api/validation-rules` runs a SOQL query against the **Tooling API's `ValidationRule` entity**, filtered to the Account object:

```sql
SELECT Id, ValidationName, Active, Description, ErrorMessage,
       CreatedDate, LastModifiedDate, CreatedBy.Name, LastModifiedBy.Name
FROM ValidationRule
WHERE EntityDefinition.QualifiedApiName = 'Account'
```

This is a real-time, read-only query — it reflects whatever rules currently exist in the connected org, regardless of their names or count.

### 3. Toggling Rules (Client-Side State)
Toggling a single rule, or bulk Enable All / Disable All, updates the **in-memory rules array** (round-tripped through the backend for consistency) without touching Salesforce yet. This lets users stage multiple changes before committing them.

### 4. Deploying Changes (Metadata API)
Clicking **Deploy Changes** sends the full rules array to `POST /api/deploy`, which:

1. **Builds a deployment package in memory** — a ZIP containing:
   - `package.xml` (manifest declaring the `Account` CustomObject)
   - `objects/Account.object` — XML containing a `<validationRules>` block per rule, with the new `<active>` flag
2. **Submits the ZIP** to Salesforce's Metadata API SOAP endpoint (`/services/Soap/m/59.0`) using a `deploy()` call
3. **Polls** `checkDeployStatus()` every 3 seconds until Salesforce reports `Succeeded` or `Failed`
4. Returns the deployment ID, component count, and any errors to the frontend

Because validation rules are **child metadata of the parent CustomObject**, the deploy only needs to send the `active` flag per rule — Salesforce merges it into the existing rule definition rather than overwriting the whole thing.

### 5. No Hardcoding
Every piece of org-specific data — credentials, instance URL, org ID, rule names, rule IDs — is retrieved dynamically at runtime. The same codebase works against **any** Salesforce Developer Edition org without modification.

---

## API Reference

See [`docs/API.md`](docs/API.md) for full request/response examples for every endpoint.

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Authenticate with Salesforce |
| POST | `/api/auth/logout` | Destroy session |
| GET  | `/api/auth/status` | Check current session |
| GET  | `/api/validation-rules` | Fetch Account validation rules |
| POST | `/api/validation-rules/toggle` | Toggle one rule (client-side state) |
| POST | `/api/validation-rules/enable-all` | Mark all rules active (client-side state) |
| POST | `/api/validation-rules/disable-all` | Mark all rules inactive (client-side state) |
| POST | `/api/deploy` | Deploy active-status changes to Salesforce |

---

## Deployment Guide

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) for deploying:
- **Frontend** → Vercel or Netlify
- **Backend** → Render or Railway

---

## Security Notes

- Salesforce access tokens are **never sent to the browser** — they live only in the server-side session store.
- Sessions use `httpOnly`, `secure` (in production), and `sameSite` cookies.
- `helmet` sets standard security headers; `express-rate-limit` throttles abusive request patterns.
- No credentials, tokens, org IDs, or rule names are hardcoded anywhere in the codebase.
- For production use beyond a demo, consider migrating from username/password+token auth to **OAuth 2.0 Web Server Flow** (Salesforce Connected App) for better security and to support orgs with MFA enforced.

---

## Troubleshooting

| Issue | Likely Cause | Fix |
|---|---|---|
| `INVALID_LOGIN` error | Wrong password, or security token required but missing | Append your security token, or reset it via Salesforce Settings |
| `INVALID_SESSION_ID` during deploy | Session expired mid-operation | Log out and back in |
| CORS error in browser console | `FRONTEND_URL` in backend `.env` doesn't match actual frontend origin | Update `FRONTEND_URL` to match exactly (including port) |
| Deploy stuck "Pending" | Org metadata cache warming up on first deploy | Wait — polling will continue up to 90 seconds |
| No rules returned | No validation rules exist on Account in that org | Create one — see Salesforce Setup Guide |
