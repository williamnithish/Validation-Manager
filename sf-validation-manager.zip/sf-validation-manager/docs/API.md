# API Reference

Base URL (local): `http://localhost:5000/api`
Base URL (production): `https://<your-backend-domain>/api`

All endpoints except `/auth/login` and `/auth/status` require an active session (sent automatically via cookie after login). All responses are JSON. All requests/responses use `Content-Type: application/json`.

---

## Authentication

### `POST /auth/login`

Authenticates against Salesforce and creates a server-side session.

**Request body:**
```json
{
  "username": "you@example.com",
  "password": "yourPassword",
  "securityToken": "abc123XYZ",
  "loginUrl": "https://login.salesforce.com"
}
```

| Field | Required | Notes |
|---|---|---|
| `username` | Yes | Salesforce username (usually email format) |
| `password` | Yes | Salesforce password |
| `securityToken` | No | Appended to password internally if provided |
| `loginUrl` | No | Defaults to `https://login.salesforce.com`; use `https://test.salesforce.com` for sandboxes |

**Success response (200):**
```json
{
  "success": true,
  "message": "Successfully connected to Salesforce.",
  "org": {
    "instanceUrl": "https://yourorg.my.salesforce.com",
    "userId": "0055g00000ABCDeAA0",
    "orgId": "00D5g000000ABCDEAA",
    "username": "you@example.com"
  }
}
```

**Error response (401):**
```json
{
  "error": "InvalidCredentials",
  "message": "Invalid username, password, or security token. Please check your credentials."
}
```

---

### `POST /auth/logout`

Destroys the current session.

**Success response (200):**
```json
{ "success": true, "message": "Logged out successfully." }
```

---

### `GET /auth/status`

Checks whether a session is currently active. Used on app load to restore state without re-prompting login.

**Authenticated response (200):**
```json
{
  "authenticated": true,
  "org": {
    "instanceUrl": "https://yourorg.my.salesforce.com",
    "orgId": "00D5g000000ABCDEAA",
    "username": "you@example.com"
  }
}
```

**Unauthenticated response (200):**
```json
{ "authenticated": false }
```

---

## Validation Rules

> All endpoints below require a valid session. Without one, every call returns:
> ```json
> { "error": "Unauthorized", "message": "You must be logged in to access this resource." }
> ```
> with HTTP status `401`.

### `GET /validation-rules`

Fetches all validation rules on the Account object via the Tooling API.

**Success response (200):**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "id": "03d5g00000ABCDEAA0",
      "name": "Require_Account_Phone",
      "active": true,
      "description": "",
      "errorMessage": "Phone number is required for this account.",
      "errorDisplayField": "Phone",
      "errorConditionFormula": "AND(ISBLANK(Phone), Industry <> \"None\")",
      "entityDefinitionId": "01I5g000000ABCDEAA",
      "createdDate": "2026-01-15T10:22:00.000+0000",
      "lastModifiedDate": "2026-03-02T14:05:00.000+0000",
      "createdBy": "Jane Admin",
      "lastModifiedBy": "Jane Admin"
    }
  ]
}
```

---

### `POST /validation-rules/toggle`

Flips the `active` flag for one rule, in the array passed in (does not call Salesforce — staging only; use `/deploy` to persist).

**Request body:**
```json
{
  "rules": [ /* full array of rule objects as returned by GET /validation-rules */ ],
  "targetId": "03d5g00000ABCDEAA0"
}
```

**Success response (200):**
```json
{ "success": true, "data": [ /* updated rules array */ ] }
```

---

### `POST /validation-rules/enable-all`

Sets `active: true` on every rule in the provided array (staging only).

**Request body:**
```json
{ "rules": [ /* full array of rule objects */ ] }
```

**Success response (200):**
```json
{ "success": true, "data": [ /* updated rules array, all active */ ] }
```

---

### `POST /validation-rules/disable-all`

Sets `active: false` on every rule in the provided array (staging only).

**Request body:**
```json
{ "rules": [ /* full array of rule objects */ ] }
```

**Success response (200):**
```json
{ "success": true, "data": [ /* updated rules array, all inactive */ ] }
```

---

## Deployment

### `POST /deploy`

Deploys the current `active` status of each rule back to Salesforce using the Metadata API. This is the only endpoint in the validation-rules flow that actually changes data in Salesforce.

**Request body:**
```json
{
  "rules": [
    {
      "name": "Require_Account_Phone",
      "active": false,
      "errorConditionFormula": "AND(ISBLANK(Phone), Industry <> \"None\")",
      "errorMessage": "Phone number is required for this account."
    },
    {
      "name": "Require_Account_Website",
      "active": true,
      "errorConditionFormula": "ISBLANK(Website)",
      "errorMessage": "Website is required."
    }
  ]
}
```

> In practice, the frontend passes through the **full rule objects** returned by `GET /validation-rules` (which already include `errorConditionFormula` and `errorMessage` from the org), so the original rule logic is preserved exactly — only the `active` flag changes.

> Note: the deploy endpoint matches rules by `name` (the Salesforce `fullName`), not `id`, since Metadata API deployments reference components by name.

**Success response (200):**
```json
{
  "success": true,
  "message": "Deployment succeeded. 2 component(s) deployed.",
  "deploymentId": "0Af5g00000ABCDEAA",
  "status": "Succeeded",
  "deployed": 2,
  "errors": 0
}
```

**Failure response (400):**
```json
{
  "error": "DeploymentFailed",
  "message": "Deployment Failed.",
  "status": "Failed",
  "errors": [
    {
      "component": "Account.Require_Account_Phone",
      "problem": "Error condition formula references an invalid field.",
      "problemType": "Error"
    }
  ]
}
```

---

## Error Shape Reference

All errors follow a consistent shape:

```json
{
  "error": "ErrorCode",
  "message": "Human-readable description.",
  "details": { /* optional, present for some Salesforce API errors */ }
}
```

| HTTP Status | Meaning |
|---|---|
| 400 | Validation error (missing fields) or deployment failure |
| 401 | Not authenticated, or invalid Salesforce credentials |
| 404 | Route not found |
| 429 | Rate limit exceeded (100 requests / 15 min per IP) |
| 500 | Unexpected server or Salesforce API error |
