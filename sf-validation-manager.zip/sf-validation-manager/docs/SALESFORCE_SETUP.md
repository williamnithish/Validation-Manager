# Salesforce Setup Guide

This guide walks through everything needed on the Salesforce side before using the Validation Rule Manager app: creating a Developer Edition org, adding sample validation rules to test with, retrieving your security token, and confirming your user has the right permissions.

---

## 1. Create a Salesforce Developer Edition Org

If you don't already have one:

1. Go to [https://developer.salesforce.com/signup](https://developer.salesforce.com/signup)
2. Fill in the signup form (no credit card required).
3. Check your email for a verification link and set your password.
4. Log in at [https://login.salesforce.com](https://login.salesforce.com) to confirm access.

Developer Edition orgs are free, permanent, and fully API-enabled — ideal for this project.

---

## 2. Create Sample Validation Rules on Account

The app reads whatever validation rules already exist on the Account object — it does not create them for you. To have something to test against:

1. In Salesforce, click the **Setup gear icon** → **Setup**.
2. In Quick Find, type **Object Manager** and open it.
3. Click **Account**.
4. In the left sidebar, click **Validation Rules**.
5. Click **New**.
6. Fill in a simple example:
   - **Rule Name**: `Require_Account_Phone`
   - **Active**: checked
   - **Error Condition Formula**:
     ```
     AND(
       ISBLANK(Phone),
       Industry <> "None"
     )
     ```
   - **Error Message**: `Phone number is required for this account.`
7. Click **Save**.

Repeat to create 2–3 more rules with different names so the table in the app has multiple rows to demonstrate search, filter, and bulk actions against. Example additional rules:
   - `Require_Account_Website` — error if `Website` is blank
   - `Block_Test_Account_Names` — error if `Name` contains "test"

---

## 3. Retrieve Your Security Token

Salesforce requires a security token for API/SOAP login when your IP address isn't in a trusted range.

1. Click your **avatar (top right)** → **Settings**.
2. In Quick Find, type **Reset My Security Token**.
3. Click **Reset Security Token**.
4. Check your email — Salesforce sends the new token immediately.
5. Keep this token handy; you'll paste it into the app's optional **Security Token** field, or append it directly to your password if you prefer.

> **Tip**: If your org has **trusted IP ranges** configured (Setup → Network Access) and you're logging in from a listed IP, you may not need a security token at all — leave the field blank and log in with just your username/password.

---

## 4. Confirm Required User Permissions

The Salesforce user you log in with needs:

| Permission | Why it's needed |
|---|---|
| **API Enabled** | Required for Tooling API queries and Metadata API calls |
| **Customize Application** | Required to read/modify validation rule metadata |
| **Modify Metadata Through Metadata API Functions** | Required to deploy changes via the Metadata API |

System Administrator profile (the default profile for Developer Edition signups) includes all of these automatically. If you're using a custom profile, check via:

**Setup → Users → Profiles → [Your Profile] → System Permissions**

---

## 5. Login URL Reference

| Org Type | Login URL |
|---|---|
| Developer Edition / Production | `https://login.salesforce.com` |
| Sandbox | `https://test.salesforce.com` |

The app's login form includes a dropdown to select between these — choose the one matching your org type.

---

## 6. Verify Everything Works

Once your rules and credentials are ready:

1. Start the app (see main [README](../README.md) for local setup).
2. Log in with your username, password, and security token.
3. Click **Get Metadata** — you should see the validation rules you created in Step 2.
4. Toggle one rule off, click **Deploy Changes**, then verify in Salesforce Setup (Object Manager → Account → Validation Rules) that it now shows as inactive.

If the rule's status updates correctly in Salesforce, your setup is complete.
