# Deployment Guide

Instructions for deploying the backend to **Render** or **Railway**, and the frontend to **Vercel** or **Netlify**.

---

## Overview

```
Frontend (static SPA)  →  Vercel / Netlify
Backend (Node/Express) →  Render / Railway
```

The frontend talks to the backend exclusively via `/api/*` REST calls using `VITE_API_URL`. The backend talks to Salesforce directly. Sessions are cookie-based, so CORS and cookie settings must be configured carefully across two different domains.

---

## Part 1 — Deploy the Backend

### Option A: Render

1. Push your code to a GitHub repository.
2. Go to [render.com](https://render.com) → **New** → **Web Service**.
3. Connect your repo, set:
   - **Root Directory**: `backend`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Runtime**: Node
4. Add environment variables (Render dashboard → Environment):
   ```
   PORT=10000
   NODE_ENV=production
   SESSION_SECRET=<generate a long random string>
   FRONTEND_URL=https://your-frontend.vercel.app
   SF_LOGIN_URL=https://login.salesforce.com
   ```
5. Deploy. Render will give you a URL like `https://sf-validation-backend.onrender.com`.
6. Verify it's live by opening `https://<your-backend-url>/health` — you should see `{"status":"ok",...}`.

> **Shortcut**: a ready-to-use `render.yaml` blueprint is included at the project root. Choosing **New → Blueprint** instead of **Web Service** lets Render read it and pre-fill most of the settings above automatically.

### Option B: Railway

1. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**.
2. Set the **root directory** to `backend` in the service settings.
3. Railway auto-detects Node.js and runs `npm install && npm start`.
4. Add the same environment variables as above under **Variables**.
5. Railway provides a public URL once deployed — copy it for the frontend config.

---

## Part 2 — Deploy the Frontend

### Option A: Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New Project** → import your repo.
2. Set **Root Directory** to `frontend`.
3. Framework preset: **Vite**.
4. Add environment variable:
   ```
   VITE_API_URL=https://your-backend.onrender.com
   ```
5. Deploy. Vercel gives you a URL like `https://sf-validation-manager.vercel.app`.

> A `vercel.json` is included in `frontend/` that adds an SPA rewrite rule, so directly opening or refreshing a route like `/dashboard` won't 404. Vercel picks this up automatically — no extra setup needed.

### Option B: Netlify

1. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**.
2. Set **Base directory** to `frontend`.
3. **Build command**: `npm run build`
4. **Publish directory**: `frontend/dist`
5. Add environment variable `VITE_API_URL` pointing to your backend URL.
6. Deploy.

> A `netlify.toml` is included in `frontend/` with the build command, publish directory, and SPA redirect already configured — Netlify reads it automatically, so steps 3–4 above are just there for reference.

---

## Part 3 — Wire the Two Together

After both are deployed, you must update each side to know about the other:

1. **Backend** → set `FRONTEND_URL` to your actual Vercel/Netlify URL (no trailing slash), then redeploy.
2. **Frontend** → set `VITE_API_URL` to your actual Render/Railway URL, then redeploy (Vite env vars are baked in at build time).

### Cross-Domain Cookie Settings

Since frontend and backend live on different domains in production, the session cookie must be configured for cross-site use. This is already handled in `server.js`:

```js
cookie: {
  secure: process.env.NODE_ENV === 'production',   // HTTPS only
  httpOnly: true,
  sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax',
}
```

`sameSite: 'none'` requires `secure: true` (HTTPS) — both Render/Railway and Vercel/Netlify serve over HTTPS by default, so this works out of the box.

---

## Part 4 — Verify the Deployment

1. Open your deployed frontend URL.
2. Open browser DevTools → Network tab.
3. Attempt to log in — confirm the request goes to your backend URL and returns a `Set-Cookie` header.
4. Click **Get Metadata** — confirm validation rules load.
5. Toggle a rule and deploy — confirm the deployment status banner appears.

---

## Common Deployment Issues

| Symptom | Cause | Fix |
|---|---|---|
| Login request blocked by CORS | `FRONTEND_URL` on backend doesn't exactly match frontend's deployed origin | Update and redeploy backend |
| Session doesn't persist after login | Cookie `sameSite`/`secure` mismatch, or testing over HTTP | Ensure both services use HTTPS in production |
| 404 on `/api/*` routes from frontend | `VITE_API_URL` missing or wrong at build time | Set the env var in your hosting dashboard and trigger a rebuild |
| Render/Railway service sleeps and first request times out | Free tier cold starts | Expected on free tiers; consider a paid tier for always-on instances |

---

## Optional: Single-Service Deployment

For simpler demos, you can serve the built frontend as static files from the same Express backend (eliminating CORS entirely):

```js
// In server.js, after API routes:
import path from 'path';
app.use(express.static(path.join(process.cwd(), '../frontend/dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(process.cwd(), '../frontend/dist/index.html'));
});
```

Then deploy only the backend (with `frontend/dist` built and committed, or built as part of the deploy step), and skip Vercel/Netlify entirely.

---

## Salesforce-Side Setup (Required Regardless of Host)

Deploying the app does not create Salesforce validation rules or grant API access — that's separate, one-time setup on your Salesforce org:

- A Salesforce Developer Edition org (free signup at developer.salesforce.com)
- At least one validation rule on the Account object, so the table has something to display
- Your Salesforce security token (Settings → Reset My Security Token)
- A user with **API Enabled** and **Modify Metadata Through Metadata API Functions** permissions (the default System Administrator profile already has both)

Full walkthrough: [`docs/SALESFORCE_SETUP.md`](SALESFORCE_SETUP.md).

---

## What "Deployed" Does and Doesn't Mean Here

- ✅ The app is reachable at a public HTTPS URL, on real infrastructure, for free.
- ✅ Logging in with real Salesforce credentials works exactly as it does locally.
- ⚠️ Render/Railway free instances sleep after inactivity; the first request after sleeping takes tens of seconds to wake up. This is a platform limitation, not an app bug.
- ⚠️ Sessions live in the Node process's memory. If the backend instance restarts (sleep/wake cycle, redeploy, crash), all logged-in sessions are cleared and users must log in again. Fine for a demo; production use at scale would want a shared session store like Redis.
